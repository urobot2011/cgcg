//npm install express --save
//npm install -s express-session --save
//npm install ejs --save
module.exports.db_config = {
    databaseName: 'jssf',
    admin: {
        id: 'admin',
        password: 'jssf'
    },
    site: {
        url: 'http://39.125.28.98:2000/',
        title: 'jssf',
        mainMenus: [
            {href: 'http://39.125.28.98:2000/', name: 'home'}, 
            /*{href: 'http://39.125.28.98:2000/login.martyscript', name: 'login'},
            {href: 'http://39.125.28.98:2000/join.martyscript', name: 'join'}*/
        ]
    }
};