module.exports = {
    bootstrip: function(title, lang, headadds, bodyadds, CSSs, JSs, bodyclass){
        var head_CSSs = '';
        CSSs.forEach(element => {
            head_CSSs += `<link href="${element}" rel="stylesheet">`;
        });
        var head_JSs = '';
        JSs.forEach(element => {
            head_JSs += `<script src="${element}"></script>`;
        });
        var head_headadds = '';
        headadds.forEach(element => {
            head_headadds += element;
        });
        var body_bodyadds = '';
        bodyadds.forEach(element => {
            body_bodyadds += element;
        });
        /*var body_menus = '';
        menus.forEach(element => {
            body_menus += `element`;
        });*/
        return {
            head: `<!doctype html>
<html lang="${lang}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>${title}</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
        ${head_CSSs}
        ${head_headadds}
    </head>
    <body class="${bodyclass}">`,body: `
        ${head_JSs}
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        ${body_bodyadds}
    </body>
</html>`
        }
    }
}
    