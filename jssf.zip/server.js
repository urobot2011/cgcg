var express = require('express');
var session = require('express-session');
var path = require('path');
var app = express();
var http = require('http').Server(app);
var bodyParser = require('body-parser');
var fs = require('fs');
var crypto = require('crypto');
var ejs = require('ejs');

var databasejs = require('./database.js');
var database = databasejs.database(fs);
var db_config = require('./config.js').db_config;
var bootstrip = require('./theme/bootstrip.js');

var lang = 'ko';

function theme(title, headadds, bodyadds, CSSs, JSs, bodyclass){
    return bootstrip.bootstrip(title, 'ko', headadds, bodyadds, CSSs, JSs, bodyclass);
}

app.use(session({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: true,
}));

app.set('view engine', 'ejs');
app.use('/css',express.static(__dirname +'/css'));
app.use('/js',express.static(__dirname +'/js'));
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());

function password_hash(password, fun){
    crypto.randomBytes(64, (err, buf) => {
        crypto.pbkdf2(password, buf.toString('base64'), 100000, 64, 'sha512', (err, key) => {
            fun(key.toString('base64'), buf.toString('base64'));
            return true;
        });
    });
}

function password_hash_check(password, buf, fun){
    crypto.pbkdf2(password, buf, 100000, 64, 'sha512', (err, key) => {
        fun(key.toString('base64'));
        return true;
    });
}

if(!fs.existsSync("./database")){
    fs.mkdirSync('./database');
    fs.mkdirSync('./database/'+db_config.databaseName);
    var db = new database(db_config.databaseName);
    var db_user = db.table.making('user');
    password_hash(db_config.admin.password, (password, hash) => {
        db_user.write({id: db_config.admin.id, password: password, hash: hash, isadmin: true});
    });
    var db_site = db.table.making('site');
    db_site.write(db_config.site, 'coverOver');
}

var db = new database(db_config.databaseName);
var db_user = db.table.table('user');
var db_site = db.table.table('site');

function getUserInfo(id){
    var users = db_user.read();
    var userInfo = null;
    users.some((element) => {
        if(element.id == id){
            userInfo = element;
            return true;
        }
    });
    return userInfo;
}

function getSiteInfo(){
    var siteInfo = db_site.read();
    return siteInfo;
}

function setSiteInfo(siteInfo){
    db_site.write(siteInfo, 'coverOver');
    return true;
}

var jssf = {
    url: {
        login: getSiteInfo().url+'login.martyscript',
        logout: getSiteInfo().url+'logout.martyscript',
        join: getSiteInfo().url+'join.martyscript',
		admin: getSiteInfo().url+'admin/'
    }
};

app.get('/', function(req, res){
    var data = {req: req, lang: lang, jssf: jssf, SiteInfo: getSiteInfo(), userInfo: getUserInfo(req.session.userid)};
    res.render('../theme/bootstrip/index', data);
});

app.get('/login.martyscript', function(req, res){
    var data = {req: req, lang: lang, jssf: jssf, SiteInfo: getSiteInfo(), userInfo: getUserInfo(req.session.userid)};
    res.render('../theme/bootstrip/login', data);
});

app.get('/logout.martyscript', function(req, res){
    var data = {req: req, lang: lang, jssf: jssf, SiteInfo: getSiteInfo(), userInfo: getUserInfo(req.session.userid)};
    res.render('../theme/bootstrip/logout', data);
});

app.get('/join.martyscript', function(req, res){
    var data = {req: req, lang: lang, jssf: jssf, SiteInfo: getSiteInfo(), userInfo: getUserInfo(req.session.userid)};
    res.render('../theme/bootstrip/join', data);
});

app.post('/api/login.martyscript', function(req, res){
    if(req.session.isLogined == true){
        res.send(JSON.stringify({
            type: 'danger',
            message: 'You are already logged in.'
        }));
    } else {
        var post = req.body;
        var id = post.id;
        var password = post.password;
        var userInfo = getUserInfo(id);
        if(userInfo != null){
            password_hash_check(password, userInfo.hash, (hash) => {
                if(hash == userInfo.password){
                    req.session.userid = id;
                    req.session.isLogined = true;
                    res.send(JSON.stringify({
                        type: 'success',
                        message: 'You are logged in!'
                    }));
                } else {
                    res.send(JSON.stringify({
                        type: 'danger',
                        message: 'The username or password is incorrect.'
                    }));
                }
            });
        } else {
            res.send(JSON.stringify({
                type: 'danger',
                message: 'The username or password is incorrect.'
            }));
        }
    }
});

app.post('/api/logout.martyscript', function(req, res){
    if(req.session.isLogined != true){
        res.send(JSON.stringify({
            type: 'danger',
            message: 'You are not logged in.'
        }));
    } else {
        req.session.userid = null;
        req.session.isLogined = false;
        res.send(JSON.stringify({
            type: 'success',
            message: 'You are logged out! bye!'
        }));
    }
});

app.post('/api/join.martyscript', function(req, res){
    if(req.session.isLogined == true){
        res.send(JSON.stringify({
            type: 'danger',
            message: 'You are already logged in.'
        }));
    } else {
        var post = req.body;
        var id = post.id;
        var password = post.password;
        var userInfo = getUserInfo(id);
        if(userInfo == null){
            password_hash(password, (password, hash) => {
                db_user.write({id: id, password: password, hash: hash, isadmin: false});
                req.session.userid = id;
                req.session.isLogined = true;
                res.send(JSON.stringify({
                    type: 'success',
                    message: 'wow! You have become a member of this site!'
                }));
            });
        } else {
            res.send(JSON.stringify({
                type: 'danger',
                message: 'I already have the same username.'
            }));
        }
    }
});

app.get('/admin/', function(req, res){
	var userInfo = getUserInfo(req.session.userid);
    if(userInfo == null || (userInfo != null && userInfo.isadmin == false)){
		res.send(`
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Error</title>
</head>
<body>
<pre>Cannot GET /admin</pre>
</body>
</html>`);
	} else if(userInfo != null && userInfo.isadmin == true){
		var title = 'admin';
		main(req, res, title, [], [], [], []);
	}
});


http.listen(2000, function() {
	console.log('server on!');
});
console.log('server start!');