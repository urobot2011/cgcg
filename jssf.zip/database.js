module.exports = {
    database: function(fs){
        function database_table(table){
            var read = JSON.parse(fs.readFileSync(table).toString());
            return {
                write: function(write, mode = "write"){
                    const dataBuffer = fs.readFileSync(table)
                    const dataJSON = dataBuffer.toString()
                    var json = JSON.parse(dataJSON);
                    if(mode == 'coverOver'){
                        if(typeof write == 'object'){
                            json = write;
                        } else {
                            json = [write];
                        }
                    } else {
                        json.push(write);
                    }
                    fs.writeFileSync(table,JSON.stringify(json));
                    read = json;
                },
                read: function(){
                    return read;
                },
                readfile: function(){
                    const dataBuffer = fs.readFileSync(table)
                    const dataJSON = dataBuffer.toString();
                    return JSON.parse(dataJSON);
                }
            };
        }
        function database(databaseName){
            return {
                table: {
                    making: function(table){
                        fs.writeFileSync('./database/'+databaseName+'/'+table,JSON.stringify([]));
                        return database_table('./database/'+databaseName+'/'+table);
                    },
                    table: function(table){
                        return database_table('./database/'+databaseName+'/'+table);
                    },
                    check: function(table){
                        return fs.existsSync('./database/'+databaseName+'/'+table);
                    },
                    tables: function(){
                        fs.readdir('./database/'+databaseName, function(err, filelist){
                            if(err) console.error(err);
                            return filelist;
                        });
                    }
                }
            };
        }
        return database;
    }
};