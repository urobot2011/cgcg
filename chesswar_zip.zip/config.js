//npm install express --save
//npm install -s express-session --save
//npm install ejs --save
var ip = '39.125.28.98:9000';
ip = 'urobot2011.iptime.org:9999';
module.exports.db_config = {
    databaseName: 'ChessWar',// 여기는 공백없어야해요 한글도없어야해요 특수문자도없어야해여
    secret: 'ChessWar urobot2011 chess Marty script',
    admin: {
        id: '컬그',
        password: '컬그는천재'
    },
    site: {
        url: 'http://'+ip+'/',
        title: '컬그의 체스',
        mainMenus: [
            {href: 'http://'+ip+'/', name: 'home'}, 
        ]
    },
    clubs: []
};