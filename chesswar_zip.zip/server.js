var express = require('express');
var session = require('express-session');
var path = require('path');
var app = express();
var http = require('http').Server(app);
var bodyParser = require('body-parser');
var fs = require('fs');
var crypto = require('crypto');
var ejs = require('ejs');
var server = require('http').createServer(app);
var io = require('socket.io')(server);
var axios = require("axios");
var cheerio = require("cheerio");

var databasejs = require('./database.js');
var database = databasejs.database(fs);
var db_config = require('./config.js').db_config;
var bootstrip = require('./theme/bootstrip.js');

var {Chess} = require("chess.js");

var lang = 'ko';

function theme(title, headadds, bodyadds, CSSs, JSs, bodyclass){
    return bootstrip.bootstrip(title, 'ko', headadds, bodyadds, CSSs, JSs, bodyclass);
}

const sessionMiddleware = session({
    secret: "keyboard cat",
    resave: false,
    saveUninitialized: false
});

app.use(sessionMiddleware);

io.engine.use(sessionMiddleware);

app.set('view engine', 'ejs');
app.use('/css',express.static(__dirname +'/css'));
app.use('/js',express.static(__dirname +'/js'));
app.use('/lib',express.static(__dirname +'/lib'));
app.use(bodyParser.urlencoded({extended: false}));
app.use(bodyParser.json());

function password_hash(password, fun){
    crypto.randomBytes(64, (err, buf) => {
        crypto.pbkdf2(password, buf.toString('base64'), 100000, 64, 'sha512', (err, key) => {
            fun(key.toString('base64'), buf.toString('base64'));
            return true;
        });
    });
}

function password_hash_check(password, buf, fun){
    crypto.pbkdf2(password, buf, 100000, 64, 'sha512', (err, key) => {
        fun(key.toString('base64'));
        return true;
    });
}

if(!fs.existsSync("./database")){
    fs.mkdirSync('./database');
    fs.mkdirSync('./database/'+db_config.databaseName);
    var db = new database(db_config.databaseName);
    var db_user = db.table.making('user');
    password_hash(db_config.admin.password, (password, hash) => {
        db_user.write({id: db_config.admin.id, password: password, hash: hash, isadmin: true, rating: 1500, games: []});
    });
    var db_site = db.table.making('site');
    db_site.write(db_config.site, 'coverOver');
    var db_chat = db.table.making('chat');
    db_chat.write({}, 'coverOver');
}

var db = new database(db_config.databaseName);
var db_user = db.table.table('user');
var db_site = db.table.table('site');
var db_chat = db.table.table('chat');

function getUserInfo(id){
    var users = db_user.read();
    var userInfo = null;
    users.some((element) => {
        if(element.id == id){
            userInfo = element;
            return true;
        }
    });
    return userInfo;
}
function setUserInfo(id, userInfo){
    var users = db_user.read();
    var userInfos = [];
    users.some((element) => {
        if(element.id == id){
            userInfos.push(userInfo);
        } else {
            userInfos.push(element);
        }
    });
    db_user.write(userInfos, 'coverOver');
    return true;
}

function getSiteInfo(){
    var siteInfo = db_site.read();
    return siteInfo;
}

function setSiteInfo(siteInfo){
    db_site.write(siteInfo, 'coverOver');
    return true;
}

var jssf = {
    url: {
        login: getSiteInfo().url+'login.martyscript',
        logout: getSiteInfo().url+'logout.martyscript',
        join: getSiteInfo().url+'join.martyscript',
        EditMemberInfo: getSiteInfo().url+'EditMemberInfo.martyscript',
        play: getSiteInfo().url+'play.martyscript'
    }
};

app.get('/', function(req, res){
    var data = {req: req, lang: lang, jssf: jssf, SiteInfo: getSiteInfo(), userInfo: getUserInfo(req.session.userid)};
    res.render('../theme/bootstrip/index', data);
});

app.get('/login.martyscript', function(req, res){
    var data = {req: req, lang: lang, jssf: jssf, SiteInfo: getSiteInfo(), userInfo: getUserInfo(req.session.userid)};
    res.render('../theme/bootstrip/login', data);
});

app.get('/logout.martyscript', function(req, res){
    var data = {req: req, lang: lang, jssf: jssf, SiteInfo: getSiteInfo(), userInfo: getUserInfo(req.session.userid)};
    res.render('../theme/bootstrip/logout', data);
});

app.get('/join.martyscript', function(req, res){
    var data = {req: req, lang: lang, jssf: jssf, SiteInfo: getSiteInfo(), userInfo: getUserInfo(req.session.userid)};
    res.render('../theme/bootstrip/join', data);
});

app.get('/EditMemberInfo.martyscript', function(req, res){
    var data = {req: req, lang: lang, jssf: jssf, SiteInfo: getSiteInfo(), userInfo: getUserInfo(req.session.userid)};
    res.render('../theme/bootstrip/EditMemberInfo', data);
});

app.get('/play.martyscript', function(req, res){
    var data = {req: req, lang: lang, jssf: jssf, SiteInfo: getSiteInfo(), userInfo: getUserInfo(req.session.userid), users: db_user.read()};
    res.render('../theme/bootstrip/play', data);
});

app.post('/api/login.martyscript', function(req, res){
    if(req.session.isLogined == true){
        res.send(JSON.stringify({
            type: 'danger',
            message: 'You are already logged in.'
        }));
    } else {
        var post = req.body;
        var id = post.id;
        var password = post.password;
        var userInfo = getUserInfo(id);
        if(userInfo != null){
            password_hash_check(password, userInfo.hash, (hash) => {
                if(hash == userInfo.password){
                    req.session.userid = id;
                    req.session.isLogined = true;
                    res.send(JSON.stringify({
                        type: 'success',
                        message: 'You are logged in!'
                    }));
                } else {
                    res.send(JSON.stringify({
                        type: 'danger',
                        message: 'The username or password is incorrect.'
                    }));
                }
            });
        } else {
            res.send(JSON.stringify({
                type: 'danger',
                message: 'The username or password is incorrect.'
            }));
        }
    }
});

app.post('/api/logout.martyscript', function(req, res){
    if(req.session.isLogined != true){
        res.send(JSON.stringify({
            type: 'danger',
            message: 'You are not logged in.'
        }));
    } else {
        req.session.userid = null;
        req.session.isLogined = false;
        res.send(JSON.stringify({
            type: 'success',
            message: 'You are logged out! bye!'
        }));
    }
});

app.post('/api/join.martyscript', function(req, res){
    if(req.session.isLogined == true){
        res.send(JSON.stringify({
            type: 'danger',
            message: 'You are already logged in.'
        }));
    } else {
        var post = req.body;
        var id = post.id;
        var password = post.password;
        var userInfo = getUserInfo(id);
        if(userInfo == null && !id.includes(' ')){
            password_hash(password, (password, hash) => {
                db_user.write({id: id, password: password, hash: hash, isadmin: false, rating: 1500, games: []});
                req.session.userid = id;
                req.session.isLogined = true;
                res.send(JSON.stringify({
                    type: 'success',
                    message: 'wow! You have become a member of this site!'
                }));
            });
        } else {
            res.send(JSON.stringify({
                type: 'danger',
                message: 'The same username already exists or there is a space(\' \') in the username.'
            }));
        }
    }
});

app.post('/api/EditMemberInfo.martyscript', function(req, res){
    if(req.session.isLogined != true){
        res.send(JSON.stringify({
            type: 'danger',
            message: 'You are not logged in.'
        }));
    } else {
        var post = req.body;
        var id = post.id;
        var password = post.password;
        var olduserInfo = getUserInfo(req.session.userid);
        var userInfo = getUserInfo(id);
        if(userInfo == null || req.session.userid == userInfo.id){
            password_hash(password, (password, hash) => {
                setUserInfo(id, {id: id, password: password, hash: hash, isadmin: false, rating: olduserInfo.rating , games: olduserInfo.games});
                req.session.userid = id;
                res.send(JSON.stringify({
                    type: 'success',
                    message: 'wow! User information has been successfully changed!'
                }));
            });
        } else {
            res.send(JSON.stringify({
                type: 'danger',
                message: 'I already have the same username.'
            }));
        }
    }
});

app.get('/api/member/:param', function(req, res){
    if(req.session.isLogined == true) {
        var param = req.params.param;
        var userinfo = getUserInfo(param);
        if(userinfo != null) {
            res.send(JSON.stringify({
                message: {
                    type: 'success',
                    message: 'processing success!'
                },
                data: {rating: userinfo.rating, games: userinfo.games}
            }));
        } else {
            res.send(JSON.stringify({
                message: {
                    type: 'danger',
                    message: 'That member does not exist.'
                },
                data: 'error'
            }));
        }
    } else {
        res.send(JSON.stringify({
            message: {
                type: 'danger',
                message: 'You are not logged in.'
            },
            data: 'error'
        }));
    }
});

var gameIndex = 0;
var site = {};
site.games = {};
site.mode = {sender: 'sender', receiver: 'receiver'};
site.users = {};

function RatingCalc(myRating, oppRating, games, win){
    // chess.com: 8.888888888888889
    var K = games.length > 30 ? 10 : 30;
    var We = 1 / (10^(oppRating - myRating)/400 + 1);
    var Pa = K * (win - We);
    return parseInt(Pa);
}

app.get('/game/:param', function(req, res){
    var data = {req: req, lang: lang, jssf: jssf, SiteInfo: getSiteInfo(), userInfo: getUserInfo(req.session.userid), users: db_user.read(), game: req.params.param, gameinfo: site.games[req.params.param]};
    res.render('../theme/bootstrip/watch', data);
});

app.get('/watch/:param', function(req, res){
    var data = {req: req, lang: lang, jssf: jssf, SiteInfo: getSiteInfo(), userInfo: getUserInfo(req.session.userid), users: db_user.read(), game: req.params.param, gameinfo: site.games[req.params.param]};
    res.render('../theme/bootstrip/watch', data);
});

io.on("connection", (socket) => {
    var req = socket.request;
    var session = req.session;
    if(session.isLogined == true){
        var userinfo = getUserInfo(session.userid);
        var rating = userinfo.rating;
        var userid = session.userid;
        socket.userid = userid;
        socket.join(socket.userid);
        var mygame = null;
        var myChessGame = null;
        var mycolor = null;

        var mode = null;

        var OPPID = null;
        var MYID = userid;

        if(site.users.hasOwnProperty(MYID)){
            var load = site.users[MYID];
            OPPID = load.oppID;
            mode = load.mode;
            mygame = load.gameID;
            myChessGame = load.gameInfo.game;
            mycolor = load.mycolor;
        }

        function chessGameOver(){
            if(myChessGame != null && myChessGame.isGameOver()){
                if(myChessGame.isCheckmate()){
                    var turn = myChessGame.turn();
                    var game = site.games[mygame];
                    var [winid, loseid] = game.color == turn ? [game.myID, game.oppID] : [game.oppID, game.myID];
                    var winuserInfo = getUserInfo(winid);
                    var loseuserInfo = getUserInfo(loseid);
                    winuserInfo.rating = winuserInfo.rating+RatingCalc(winuserInfo.rating, loseuserInfo.rating, winuserInfo.games, 1);
                    loseuserInfo.rating = loseuserInfo.rating+RatingCalc(winuserInfo.rating, loseuserInfo.rating, loseuserInfo.games, -1);
                    winuserInfo.games.push({win: 1, pgn: myChessGame.pgn(), date: new Date().toJSON()});
                    loseuserInfo.games.push({win: -1, pgn: myChessGame.pgn(), date: new Date().toJSON()});
                    setUserInfo(winid, winuserInfo);
                    setUserInfo(loseid, loseuserInfo);
                    io.to(winuserInfo).emit('game end', 1);
                    io.to(loseuserInfo).emit('game end', -1);

                    io.to('game:'+mygame).emit('game:'+mygame+' watch end', turn == 'w' ? 1 : -1);
                } else {
                    var game = site.games[mygame];
                    var [id1, id2] = [game.myID, game.oppID];
                    var userInfo1 = getUserInfo(id1);
                    var userInfo2 = getUserInfo(id2);
                    userInfo1.rating = userInfo1.rating+RatingCalc(userInfo1.rating, userInfo2.rating, userInfo1.games, 0);
                    userInfo2.rating = userInfo2.rating+RatingCalc(userInfo2.rating, userInfo1.rating, userInfo2.games, 0);
                    userInfo1.games.push({win: 0, pgn: myChessGame.pgn(), date: new Date().toJSON()});
                    userInfo2.games.push({win: 0, pgn: myChessGame.pgn(), date: new Date().toJSON()});
                    setUserInfo(id1, userInfo1);
                    setUserInfo(id2, userInfo2);
                    socket.emit('game end', 0);
                    io.to(OPPID).emit('game end', 0);

                    io.to('game:'+mygame).emit('game:'+mygame+' watch end', 0);
                }
                mode = null;
                mygame = null;
                myChessGame = null;
                mycolor = null;
                delete site.users[MYID];
                delete site.users[OPPID];
                site.games[game].end = true;
                return true;
            }
            return false;
        }

        socket.on('game challenge', function(oppID, color) {
            if(getUserInfo(oppID) != null && oppID != MYID){
                mygame = 'game'+gameIndex;
                myChessGame = null;
                mycolor = color;
                site.games[mygame] = {color: color == 'w' ? 'b' : 'w', color2: color, myID: userid, oppID, game: null, draw: false, end: false};
                io.to(oppID).emit('challenge', {gameID: mygame, gameInfo: site.games[mygame]});
                OPPID = oppID;
                gameIndex++;

                mode = site.mode.sender;
            } else {
                socket.emit('error', 'The selected user is either does not exist.');
            }
        });
        socket.on('challenge accept', function(gameID) {
            if(site.games[gameID] != undefined && site.games[gameID].oppID == MYID){
                mygame = gameID;
                mycolor = site.games[mygame].color;
                myChessGame = new Chess();
                site.games[mygame].game = myChessGame;
                OPPID = site.games[mygame].myID;
                io.to(site.games[mygame].myID).emit('challenge receive', mygame);

                mode = site.mode.receiver;
                site.users[MYID] = {gameID: mygame, gameInfo: site.games[mygame], mode: mode, mycolor: mycolor, myID: userid, oppID: OPPID};
            } else
                socket.emit('error', 'Selected game does not exist.');
        });
        socket.on('challenge receive', function(gameID) {
            if(myChessGame == null && site.games[mygame].game != null){
                myChessGame = site.games[mygame].game;

                mode = site.mode.sender;
                site.users[MYID] = {gameID: mygame, gameInfo: site.games[mygame], mode: mode, mycolor: mycolor, myID: userid, oppID: OPPID};
            } else {
                socket.emit('error', 'The game has already started.');
            }
        });
        socket.on('game pgn', function() {
            if(myChessGame != null)
                socket.emit('game pgn', myChessGame.pgn());
            else
                socket.emit('error', 'Game did not start.');
        });
        socket.on('game info', function() {
            if(myChessGame != null)
                socket.emit('game info', {gameID: mygame, gameInfo: site.games[mygame], mode: mode});
            else
                socket.emit('error', 'Game did not start.');
        });
        socket.on('game oppInfo', function() {
            if(myChessGame != null){
                var userinfo = getUserInfo(OPPID);
                socket.emit('game oppInfo', {rating: userinfo.rating, games: userinfo.games});
            } else
                socket.emit('error', 'Game did not start.');
        });
        socket.on('game move', function(move) {
            if(myChessGame != null && mycolor == myChessGame.turn() && myChessGame.move(move) != false){
                site.games[mygame].game = myChessGame;
                chessGameOver();
                io.to(OPPID).emit('game move', move);
                io.to('game:'+mygame).emit('game:'+mygame+' watch move', move);
            } else if(myChessGame == null) {
                socket.emit('error', 'Game did not start.');
            } else {
                socket.emit('error', 'That move is an illegal move.');
            }
        });
        
        socket.on('game resign', function() {
            if(myChessGame != null){
                var turn = myChessGame.turn();
                var game = site.games[mygame];
                var [winid, loseid] = [OPPID, MYID];
                var winuserInfo = getUserInfo(winid);
                var loseuserInfo = getUserInfo(loseid);
                winuserInfo.rating = winuserInfo.rating+RatingCalc(winuserInfo.rating, loseuserInfo.rating, winuserInfo.games, 1);
                loseuserInfo.rating = loseuserInfo.rating+RatingCalc(winuserInfo.rating, loseuserInfo.rating, loseuserInfo.games, -1);
                winuserInfo.games.push({win: 1, pgn: myChessGame.pgn(), date: new Date().toJSON()});
                loseuserInfo.games.push({win: -1, pgn: myChessGame.pgn(), date: new Date().toJSON()});
                setUserInfo(winid, winuserInfo);
                setUserInfo(loseid, loseuserInfo);
                mode = null;
                mygame = null;
                myChessGame = null;
                mycolor = null;
                delete site.users[MYID];
                delete site.users[OPPID];
                site.games[game].end = true;
                socket.emit('game end', -1);
                io.to(OPPID).emit('game end', 1);

                io.to('game:'+mygame).emit('game:'+mygame+' watch end', turn == 'w' ? 1 : -1);
            } else {
                socket.emit('error', 'Game did not start.');
            }
        });

        socket.on('game draw', function() {
            if(myChessGame != null){
                io.to(OPPID).emit('game draw?');
                site.games[mygame].draw = true;
            } else {
                socket.emit('error', 'Game did not start.');
            }
        });

        socket.on('game draw accept', function() {
            if(myChessGame != null && site.games[mygame].draw == true){
                var game = site.games[mygame];
                var [id1, id2] = [game.myID, game.oppID];
                var userInfo1 = getUserInfo(id1);
                var userInfo2 = getUserInfo(id2);
                userInfo1.rating = userInfo1.rating+RatingCalc(userInfo1.rating, userInfo2.rating, userInfo1.games, 0);
                userInfo2.rating = userInfo2.rating+RatingCalc(userInfo2.rating, userInfo1.rating, userInfo2.games, 0);
                userInfo1.games.push({win: 0, pgn: myChessGame.pgn(), date: new Date().toJSON()});
                userInfo2.games.push({win: 0, pgn: myChessGame.pgn(), date: new Date().toJSON()});
                setUserInfo(id1, userInfo1);
                setUserInfo(id2, userInfo2);
                mode = null;
                mygame = null;
                myChessGame = null;
                mycolor = null;
                delete site.users[MYID];
                delete site.users[OPPID];
                site.games[game].end = true;

                socket.emit('game end', 0);
                io.to(OPPID).emit('game end', 0);

                io.to('game:'+mygame).emit('game:'+mygame+' watch end', 0);
            } else {
                socket.emit('error', 'No draw requested.');
            }
        });

        socket.on('game load', function() {
            if(site.users.hasOwnProperty(MYID)){
                socket.emit('game load', {mycolor, mode, pgn: myChessGame.pgn(), oppID: OPPID, myID: MYID, mygame: mygame});
            }
        });
        
        socket.on('game chat', function(chat) {
            if(mygame != null){
                chat = chat.replace(/<[^>]*>?/g, '');
                chat = chat.replace(/(\b(https?):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/gim, '<a href="$1" target="_blank">$1</a>');
                io.to(OPPID).emit('game chat', chat);
                io.to('game:'+mygame).emit('game:'+mygame+' watch chat', MYID, chat);
            } else {
                socket.emit('error', 'Game did not start.');
            }
        });
        
        socket.on('game watch', function(game) {
            socket.join('game:'+game);
        });

        socket.on('game watch end', function(game) {
            socket.leave('game:'+game);
        });

        socket.on('game watch info', function(game) {
            if(site.games[game] != undefined){
                var Wrating = getUserInfo(site.games[game].myID).rating;
                var Brating = getUserInfo(site.games[game].oppID).rating;
                socket.emit('game:'+game+' watch info', {gameID: game, gameInfo: site.games[game], pgn: site.games[game].game.pgn(), Wrating, Brating});
            }
        });

        socket.on('game watch chat', function(game, chat) {
            if(site.games[game] != undefined){
                chat = chat.replace(/<[^>]*>?/g, '');
                chat = chat.replace(/(\b(https?):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/gim, '<a href="$1" target="_blank">$1</a>');
                io.to('game:'+mygame).emit('game:'+game+' watch chat', MYID, chat);
            } else {
                socket.emit('error', 'Game did not start.');
            }
        });

        socket.on('disconnect', function() {   
        });
    } else {
        socket.emit('error', 'You are not logged in.');
    }
});

var chatSocket = io.of("/chat");
/*chatSocket.on("connection", (socket) => {
    var req = socket.request;
    var session = req.session;
    if(session.isLogined == true){
        var userinfo = getUserInfo(session.userid);
        var rating = userinfo.rating;
        var userid = session.userid;
        socket.userid = userid;
        socket.join(socket.userid);
        socket.on('join room', function(room) {
            var rooms = db_chat.read();
            if(!rooms.hasOwnProperty(room)){
                k

            } 
            socket.join(room);
        });
        socket.on('disconnect', function() {   
        });
    } else {
        socket.emit('error', 'You are not logged in.');
    }
});*/

server.listen(9000, function() {
    console.log('server on!');
});

console.log('server start!');